import datetime

 
class Note:
    """
    Represent a note in the notebook. Match against a
    string in searches and store tags for each note.
    """   
    _Next_ID = 1   # class variables

    def __init__(self, memo, tags=""):
        """
        Initialize a note with memo and optional
        space-separated tags. Automatically set the note's
        creation date and a unique id.
        """
        self.__memo = memo
        self.__tags = tags
        self.__creation_date = datetime.date.today()
        self.__id = Note._Next_ID
        Note._Next_ID += 1
    
    def getId(self):
        return self.__id
    
    def setMemo(self, memo):
        self.__memo = memo
        
    def setTags(self, tags):
        self.__tags = tags

    def match(self, filter):
        """
        Determine if this note matches the filter text.
        Return True if it matches, False otherwise.
        Search is case sensitive, matching both text & tags.
        """
        return filter in self.__memo or filter in self.__tags

    def __str__(self):
        return "{}: {}\nMemo: {}".format(self.__id, self.__tags, self.__memo)
    
class Notebook:
    """
    Represent a collection of notes that can be tagged,
    modified, and searched.
    """
    def __init__(self):
        """Initialize a notebook with an empty list."""
        self.__notes = []

    def new_note(self, memo, tags=""):
        """Create a new note and add it to the list."""
        self.__notes.append(Note(memo, tags))

    def find_note(self, note_id):
        """Locate the note with the given id."""
        for note in self.__notes:
            if note.getId() == note_id:
                return note
        return None

    def modify_memo(self, note_id, memo):
        """Find the note with the given id and change its
        memo to the given value."""
        note = self.find_note(note_id)
        if note:
            note.setMemo(memo)
            return True
        return False

    def modify_tags(self, note_id, tags):
        """Find the note with the given id and change its
        tags to the given value."""
        note = self.find_note(note_id)
        if note:
            note.setTags(tags)
            return True
        return False

    def search(self, filter):
        """Find all notes that match the given filter
        string."""
        return [note for note in self.__notes if note.match(filter)]
    
    def __str__(self):
        text = ""
        for n in self.__notes:
            text += n.__str__() + "\n"
        return text

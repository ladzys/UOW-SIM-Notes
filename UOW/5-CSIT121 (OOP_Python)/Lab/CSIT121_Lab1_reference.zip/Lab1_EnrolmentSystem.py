class Subject:
    def __init__(self, code, name):
        self.code = code
        self.name = name
        self.teacher = None
        self.students = []

    def get_code(self):
        return self.code

    def get_name(self):
        return self.name

    def get_teacher(self):
        return self.teacher

    def get_students(self):
        return self.students

    def set_teacher(self, teacher):
        self.teacher = teacher

    def add_student(self, student):
        self.students.append(student)

    #def add_students(self, students):
        #append the new student list to the existing student list

    def remove_student(self, student):
        self.students.remove(student)

    def __str__(self):
        teacher_name = self.teacher.get_name() if self.teacher else "None"
        student_names = [student.get_name() for student in self.students]
        students_str = ", ".join(student_names) if student_names else "No students enrolled"
        return f"Subject Code: {self.code}\nSubject Name: {self.name}\nTeacher: {teacher_name}\nEnrolled Students: {students_str}"

class Teacher:
    def __init__(self, staff_id, name):
        self.staff_id = staff_id
        self.name = name
        self.subjects = []

    def get_staff_id(self):
        return self.staff_id

    def get_name(self):
        return self.name

    def get_subjects(self):
        return self.subjects

    def add_subject(self, subject):
        self.subjects.append(subject)

    def remove_subject(self, subject):
        self.subjects.remove(subject)

    def __str__(self):
        subject_names = [subject.get_name() for subject in self.subjects]
        subjects_str = ", ".join(subject_names) if subject_names else "None"
        return f"Teacher ID: {self.staff_id}\nTeacher Name: {self.name}\nTeaching Subjects: {subjects_str}"


class Student:
    def __init__(self, student_id, name):
        self.student_id = student_id
        self.name = name
        self.subjects = []

    def get_student_id(self):
        return self.student_id

    def get_name(self):
        return self.name

    def get_subjects(self):
        return self.subjects

    def add_subject(self, subject):
        self.subjects.append(subject)

    def remove_subject(self, subject):
        self.subjects.remove(subject)

    def __str__(self):
        subject_names = [subject.get_name() for subject in self.subjects]
        subjects_str = ", ".join(subject_names) if subject_names else "No subjects enrolled"
        return f"Student ID: {self.student_id}\nStudent Name: {self.name}\nEnrolled Subjects: {subjects_str}"


class EnrollmentSystem:
    def __init__(self):
        self.subjects = []
        self.teachers = []
        self.students = []

    def create_subject(self, code, name):
        subject = Subject(code, name)
        self.subjects.append(subject)
        return subject

    def create_teacher(self, staff_id, name):
        teacher = Teacher(staff_id, name)
        self.teachers.append(teacher)
        return teacher

    def create_student(self, student_id, name):
        student = Student(student_id, name)
        self.students.append(student)
        return student

    def find_subject_by_code(self, code):
        for subject in self.subjects:
            if subject.get_code() == code:
                return subject
        return None

    def find_student_by_id(self, student_id):
        for student in self.students:
            if student.get_student_id() == student_id:
                return student
        return None

if __name__ == '__main__':
    #testing cases
    # Create an instance of the EnrollmentSystem
    enrollment_system = EnrollmentSystem()

    # Create subjects
    math_subject = enrollment_system.create_subject("MATH101", "Mathematics")
    physics_subject = enrollment_system.create_subject("PHY201", "Physics")
    chemistry_subject = enrollment_system.create_subject("CHEM301", "Chemistry")

    # Create teachers
    math_teacher = enrollment_system.create_teacher("T001", "John Smith")
    physics_teacher = enrollment_system.create_teacher("T002", "Jane Doe")

    # Create students
    student1 = enrollment_system.create_student("S001", "Alice Johnson")
    student2 = enrollment_system.create_student("S002", "Bob Anderson")
    student3 = enrollment_system.create_student("S003", "Carol Wilson")

    # Assign teachers to subjects
    math_subject.set_teacher(math_teacher)
    physics_subject.set_teacher(physics_teacher)

    # Enroll students in subjects
    math_subject.add_student(student1)
    math_subject.add_student(student2)
    physics_subject.add_student(student2)
    chemistry_subject.add_student(student3)

    # Test printing subject details
    print(math_subject)
    print(physics_subject)

    # Test printing teacher details
    print(math_teacher)
    print(physics_teacher)

    # Test printing student details
    print(student1)
    print(student2)
    print(student3)

    # Search for a subject by code
    subject_code = "MATH101"
    subject = enrollment_system.find_subject_by_code(subject_code)
    if subject:
        print(f"Subject found: {subject.get_name()}")
        #print(subject)
    else:
        print("Subject not found.")

    # Search for a student by ID
    student_id = "S002"
    student = enrollment_system.find_student_by_id(student_id)
    if student:
        print(f"Student found: {student.get_name()}")
        enrolled_subjects = student.get_subjects()
        print("Enrolled Subjects:")
        for subject in enrolled_subjects:
            print(subject.get_name())
        #print(student)
    else:
        print("Student not found.")                    

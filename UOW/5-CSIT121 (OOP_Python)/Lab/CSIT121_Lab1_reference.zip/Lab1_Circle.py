import math

class Point:
    def __init__(self, x, y):
        self.x = x
        self.y = y

class Circle:
    def __init__(self, center, radius):
        self.center = center
        self.radius = radius

    def area(self):
        return math.pi * self.radius ** 2

    def circumference(self):
        return 2 * math.pi * self.radius

    def point_coordinates(self, angle):
        x = self.radius * math.cos(angle) + self.center.x
        y = self.radius * math.sin(angle) + self.center.y
        return Point(x, y)

if __name__ == '__main__':
    # Create a circle based on user's inputs
    center_x = float(input("Enter the x-coordinate of the circle's center: "))
    center_y = float(input("Enter the y-coordinate of the circle's center: "))
    radius = float(input("Enter the radius of the circle: "))

    center = Point(center_x, center_y)
    circle = Circle(center, radius)

    # circle = Circle (Point(center_x, center_y), radius)

    # Calculate and print the area and circumference of the circle
    print("Area:", circle.area())
    print("Circumference:", circle.circumference())

    # Calculate and print the coordinate of the point on the circle based on the angle
    angle = float(input("Enter the angle (in radians): "))
    point = circle.point_coordinates(angle)
    print("Point coordinates:", point.x, point.y)

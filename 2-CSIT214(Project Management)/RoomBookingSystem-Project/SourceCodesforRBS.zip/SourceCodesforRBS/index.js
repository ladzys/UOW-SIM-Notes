function login_validation() {
    var username = document.getElementById("uname").value;
    var password = document.getElementById("pwd").value;
    var role = document.getElementById("role").value;

    // Define predefined usernames and passwords for each role
    var studentCredentials = {
        username: "student",
        password: "student1"
    };

    var staffCredentials = {
        username: "staff",
        password: "staff1"
    };

    if (role === "student") {
        if (username === studentCredentials.username && password === studentCredentials.password) {
            alert("Login successful as a student!");
            window.location.href = "stroombk.html";
            // Redirect or perform other actions for students
        } else {
            alert("Invalid credentials for a student.");
        }
    } else if (role === "staff") {
        if (username === staffCredentials.username && password === staffCredentials.password) {
            alert("Login successful as staff!");
            window.location.href = "roomcreate.html";
            // Redirect or perform other actions for staff
        } else {
            alert("Invalid credentials for staff.");
        }
    } else {
        alert("Invalid role selection.");
    }
}

function book_validation()
{
    alert("Room has been reserved, payment has been made");
    window.location.reload();
    return true;

}
function bookagain_validation()
{
    alert("Room has been reserved, payment has been made");
    window.location.reload();
    return true;

}
function modify_validation(){
    alert("Changes have been made\n\
Click 'OK' to check your booking");
    window.location.reload();
    return true;
}
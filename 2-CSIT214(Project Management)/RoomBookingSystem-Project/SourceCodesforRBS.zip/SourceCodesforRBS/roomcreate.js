{
    function create_validation()
    {
        var un = document.create.uname;
        if (un.value.length < 6)
        {
            alert("Room name should be in the form of X.X.XX");
            un.focus();
            return false;
        }
        alert("Room succesfully created");
        window.location.reload();
        return true;
        
    }
}
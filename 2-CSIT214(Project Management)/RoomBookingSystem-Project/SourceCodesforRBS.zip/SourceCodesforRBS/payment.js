{
    function payment_validation()
    {
        alert("Payment has been made! Booking successful");
        window.location.reload();
        return true;
        
    }
}
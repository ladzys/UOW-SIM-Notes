
function modify_validation()
{
    alert("Please modify booking here");
    window.location.reload();
    return true;

}
function cancel_validation()
{
    alert("Your booking has been cancelled");
    window.location.reload();
    return true;

}
{
    function roomstatus_validation()
    {
        alert("Room has been published!");
        window.location.reload();
        return true;
        
    }
}